const canvas=document.getElementById('preview');
const ctx=canvas.getContext('2d');
const bg=new Image(); bg.src='template-01-background.jpg';
canvas.width=864; canvas.height=1536;
const defaults=[
 {id:'title',label:'Event title',value:'Carnival Haldi',font:'Cormorant Garamond',color:'#ffffff',size:70,align:'center',x:.50,y:.247,max:.76},
 {id:'tagline',label:'Tagline',value:'SUNSHINE, LAUGHTER,\nAND A LITTLE MISCHIEF.',font:'Montserrat',color:'#ffffff',size:24,align:'center',x:.50,y:.323,max:.70},
 {id:'description',label:'Main message',value:'Come celebrate with vibrant\ncolours, joyful traditions, and the\npeople who make this journey\nunforgettable.',font:'Cormorant Garamond',color:'#ffffff',size:30,align:'center',x:.50,y:.475,max:.78},
 {id:'date',label:'Date',value:'Saturday, September 26th',font:'Cormorant Garamond',color:'#ffffff',size:31,align:'center',x:.50,y:.642,max:.78},
 {id:'time',label:'Time',value:'11 am onwards',font:'Cormorant Garamond',color:'#ffffff',size:31,align:'center',x:.50,y:.685,max:.70},
 {id:'initials',label:'Bottom text',value:'A♥',font:'Great Vibes',color:'#ffffff',size:64,align:'center',x:.50,y:.827,max:.40}
];
const fonts=['Cormorant Garamond','Playfair Display','Great Vibes','Caveat','Montserrat','Poppins'];
let fields=JSON.parse(localStorage.getItem('tpTemplate01'))||defaults;
function esc(s){return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function renderFields(){
 const wrap=document.getElementById('fields'); wrap.innerHTML='';
 fields.forEach((f,i)=>{const div=document.createElement('div');div.className='field';
 div.innerHTML=`<div class="field-head"><span class="field-title">${esc(f.label)}</span><button class="secondary" style="padding:6px 9px;font-size:10px" data-reset="${i}">Reset style</button></div>
 <textarea data-k="value" data-i="${i}" rows="${f.id==='description'||f.id==='tagline'?3:1}">${esc(f.value)}</textarea>
 <div class="row3" style="margin-top:9px"><select data-k="font" data-i="${i}">${fonts.map(x=>`<option ${x===f.font?'selected':''}>${x}</option>`).join('')}</select><input class="color" type="color" value="${f.color}" data-k="color" data-i="${i}"/><input type="number" min="10" max="100" value="${f.size}" data-k="size" data-i="${i}" title="Font size"></div>`;
 wrap.appendChild(div)});
 wrap.querySelectorAll('[data-k]').forEach(el=>el.addEventListener('input',e=>{const i=+e.target.dataset.i,k=e.target.dataset.k;fields[i][k]=k==='size'?+e.target.value:e.target.value;save();draw()}));
 wrap.querySelectorAll('[data-reset]').forEach(b=>b.addEventListener('click',()=>{const i=+b.dataset.reset;fields[i].font=defaults[i].font;fields[i].color=defaults[i].color;fields[i].size=defaults[i].size;save();renderFields();draw()}));
}
function save(){localStorage.setItem('tpTemplate01',JSON.stringify(fields))}
function fitLines(text,fontSize,maxWidth,font){ctx.font=`${fontSize}px "${font}"`;const lines=text.split('\n');const out=[];for(const line of lines){let words=line.split(' '),cur='';for(const w of words){const t=cur?cur+' '+w:w;if(ctx.measureText(t).width<=maxWidth)cur=t;else{if(cur)out.push(cur);cur=w}}if(cur)out.push(cur)}return out}
function draw(){if(!bg.complete)return;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(bg,0,0,canvas.width,canvas.height);fields.forEach(f=>{const fs=f.size;ctx.fillStyle=f.color;ctx.textAlign=f.align;ctx.textBaseline='middle';ctx.font=`${fs}px "${f.font}"`;const maxWidth=canvas.width*f.max;const lines=fitLines(f.value,fs,maxWidth,f.font);const lineH=fs*1.25;let y=canvas.height*f.y-(lines.length-1)*lineH/2;lines.forEach(line=>{ctx.fillText(line,canvas.width*f.x,y);y+=lineH})})}
bg.onload=draw; renderFields();
document.getElementById('resetBtn').onclick=()=>{fields=JSON.parse(JSON.stringify(defaults));save();renderFields();draw()};
document.getElementById('downloadBtn').onclick=()=>{const a=document.createElement('a');a.download='themeplanner-custom-invitation.png';a.href=canvas.toDataURL('image/png');a.click()};
const modal=document.getElementById('orderModal');
document.getElementById('continueBtn').onclick=()=>{document.getElementById('summary').textContent='Template: Carnival Haldi\n\n'+fields.map(f=>f.label+': '+f.value.replaceAll('\n',' / ')).join('\n');modal.classList.remove('hidden')};
document.getElementById('closeModal').onclick=()=>modal.classList.add('hidden');
modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.add('hidden')});
document.getElementById('copyOrder').onclick=async()=>{const name=document.getElementById('customerName').value||'-';const phone=document.getElementById('customerPhone').value||'-';const notes=document.getElementById('customerNotes').value||'-';const text='Themeplanner.in Order\nTemplate: Carnival Haldi\nCustomer: '+name+'\nPhone: '+phone+'\nNotes: '+notes+'\n\n'+fields.map(f=>f.label+': '+f.value.replaceAll('\n',' / ')+` | Font: ${f.font} | Color: ${f.color} | Size: ${f.size}`).join('\n');await navigator.clipboard.writeText(text);document.getElementById('copyOrder').textContent='Copied ✓';setTimeout(()=>document.getElementById('copyOrder').textContent='Copy Order Details',1600)};
