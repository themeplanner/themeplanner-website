# Themeplanner.in — Order Now Template 01

Standalone prototype for a text-only customizable invitation template.

## Files
- `index.html` — page and order modal
- `style.css` — responsive UI
- `app.js` — live preview/editor/download/order details
- `template-01-background.jpg` — cleaned template background
- `template-01-original.jpg` — original supplied artwork

## Run
Open `index.html` in a browser or deploy the folder to your existing website.

## Integration
Replace the demo Copy Order Details action with your Themeplanner backend/API/WhatsApp/email endpoint. The customer customization is kept in localStorage in this prototype.

## Notes
The supplied artwork is used as the locked background. Editable text is rendered as canvas layers on top. Font/color/size are configurable per field.
